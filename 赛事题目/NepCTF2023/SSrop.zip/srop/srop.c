// compiled: 
// gcc -g -c -fno-stack-protector srop.c -o srop.o
// ld -e main srop.o -o srop

char global_buf[0x200];

int main()
{
    asm(// 读取最多 200 字节
        "mov $0, %%rax\n" // sys_read

        "mov $0, %%rdi\n" // fd
        "lea %0, %%rsi\n" // buf
        "mov $0x200, %%rdx\n" // count

        "syscall\n"
        // 读取字节数小于 ucontext_t结构体则直接 exit
        "cmp $0xf8, %%rax\n"
        "jb exit\n"

        // 进行恢复上下文
        "mov $0, %%rdi\n"
        "mov %%rsi, %%rsp\n"
        "mov $15, %%rax\n" // sys_rt_sigaction

        "syscall\n"
        "jmp exit\n"

        /* split */
        "nop\n"
        "nop\n"

        // syscall 的 symbol，便于查找
        "syscall:\n"
        "syscall\n" 
        "jmp exit\n"

        // 退出程序
        "exit:\n"
        "mov $60, %%rax\n"
        "mov $0, %%rsi\n"
        "syscall\n"         
        :
        : "m" (global_buf)
        : 
        );
}
